Customized Python WebHDFS client, Modified from https://pypi.org/project/PyHDFS/

1.Support setting webhdfs_path
2.Support Pylon.


